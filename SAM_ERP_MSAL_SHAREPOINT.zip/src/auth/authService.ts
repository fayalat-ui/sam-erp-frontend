import { msalInstance } from "./msalInstance";
import { loginRequest } from "./msalConfig";
import type { AccountInfo } from "@azure/msal-browser";

export async function getAccessToken(): Promise<string> {
  const accounts = msalInstance.getAllAccounts();
  let account: AccountInfo | null = accounts[0] ?? null;

  if (!account) {
    const loginResult = await msalInstance.loginPopup(loginRequest);
    account = loginResult.account!;
  }

  const tokenResponse = await msalInstance.acquireTokenSilent({
    ...loginRequest,
    account,
  });

  if (!tokenResponse.accessToken) {
    throw new Error("No se pudo obtener accessToken de MSAL");
  }

  return tokenResponse.accessToken;
}
