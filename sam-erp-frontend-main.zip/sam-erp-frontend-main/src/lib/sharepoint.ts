import { Client } from "@microsoft/microsoft-graph-client";
import type { AuthenticationProvider } from "@microsoft/microsoft-graph-client";
import { PublicClientApplication } from "@azure/msal-browser";
import { msalConfig, loginRequest } from "./msalConfig";
import { SHAREPOINT_LISTS } from "./sharepoint-mappings";

// Helpers to read environment variables for SharePoint configuration.
const SP_SITE_ID = import.meta.env.VITE_SHAREPOINT_SITE_ID as string | undefined;
const SP_HOSTNAME =
  (import.meta.env.VITE_SHAREPOINT_HOSTNAME as string | undefined) ||
  "seguryservicios.sharepoint.com";
const SP_SITE_PATH =
  (import.meta.env.VITE_SHAREPOINT_SITE_PATH as string | undefined) || "/";

// Custom authentication provider for Microsoft Graph
class MsalAuthProvider implements AuthenticationProvider {
  private msalInstance: PublicClientApplication;
  private initializedPromise: Promise<void> | null = null;

  constructor() {
    this.msalInstance = new PublicClientApplication(msalConfig);
  }

  private async ensureInitialized(): Promise<void> {
    if (!this.initializedPromise) {
      this.initializedPromise = this.msalInstance.initialize();
    }
    await this.initializedPromise;
  }

  public async getAccessToken(): Promise<string> {
    await this.ensureInitialized();

    const accounts = this.msalInstance.getAllAccounts();
    if (accounts.length === 0) {
      throw new Error("No authenticated user found");
    }

    try {
      const response = await this.msalInstance.acquireTokenSilent({
        ...loginRequest,
        account: accounts[0],
      });
      return response.accessToken;
    } catch (error) {
      console.error("Silent token acquisition failed, trying interactive:", error);
      try {
        const response = await this.msalInstance.acquireTokenPopup(loginRequest);
        return response.accessToken;
      } catch (interactiveError) {
        console.error("Interactive token acquisition failed:", interactiveError);
        throw new Error("Failed to acquire access token");
      }
    }
  }
}

class SharePointClient {
  private graphClient: Client;
  private siteId = "";
  private authProvider: MsalAuthProvider;
  private listIdCache = new Map<string, string>();

  constructor() {
    this.authProvider = new MsalAuthProvider();
    this.graphClient = Client.initWithMiddleware({
      authProvider: this.authProvider,
    });
  }

  private isGuid(id: string) {
    return /^[0-9a-fA-F-]{36}$/.test(id);
  }

  async initializeSite() {
    try {
      if (this.siteId) return { id: this.siteId };

      if (SP_SITE_ID) {
        const site = await this.graphClient.api(`/sites/${SP_SITE_ID}`).get();
        this.siteId = site.id;
        console.log(
          "SharePoint site initialized by ID:",
          site.displayName || site.id
        );
        return site;
      }

      const site = await this.graphClient
        .api(`/sites/${SP_HOSTNAME}:${SP_SITE_PATH}`)
        .get();
      this.siteId = site.id;
      console.log(
        "SharePoint site initialized by host/path:",
        site.displayName
      );
      return site;
    } catch (error) {
      console.error("Error initializing SharePoint site:", error);
      throw error;
    }
  }

  private async resolveListId(nameOrId: string): Promise<string> {
    if (!nameOrId) throw new Error("List identifier is required");

    // If passed a GUID directly
    if (this.isGuid(nameOrId)) return nameOrId;

    // Check if it's a known list key from mappings
    const listKey = nameOrId.toUpperCase() as keyof typeof SHAREPOINT_LISTS;
    if (SHAREPOINT_LISTS[listKey]) {
      const listId = SHAREPOINT_LISTS[listKey].id;
      if (this.isGuid(listId)) return listId;
    }

    // Check cache
    const cached = this.listIdCache.get(nameOrId);
    if (cached) return cached;

    // Ensure site initialized
    if (!this.siteId) {
      await this.initializeSite();
    }

    // Lookup by displayName or name
    const res = await this.graphClient
      .api(`/sites/${this.siteId}/lists`)
      .filter(`displayName eq '${nameOrId}' or name eq '${nameOrId}'`)
      .get();

    const list = Array.isArray(res?.value) ? res.value[0] : null;
    if (!list?.id) {
      throw new Error(`List not found: ${nameOrId}`);
    }

    this.listIdCache.set(nameOrId, list.id);
    return list.id;
  }

  /**
   * Get list items with optional fields selection, filter, orderBy, and top.
   * When 'select' is provided, we apply it to fields via $expand=fields($select=...)
   */
  async getListItems(
    listNameOrId: string,
    select?: string,
    filter?: string,
    orderBy?: string,
    top?: number
  ): Promise<SharePointListItem[]> {
    try {
      if (!this.siteId) {
        await this.initializeSite();
      }

      const listId = await this.resolveListId(listNameOrId);

      // Build expand for fields selection
      let expandArg = "fields";
      if (select && typeof select === "string") {
        const fieldNames = select
          .split(",")
          .map((s) => s.trim())
          // Exclude ID/id from fields selection; 'id' is top-level on listItem
          .filter((s) => s.toLowerCase() !== "id" && s.length > 0);

        if (fieldNames.length > 0) {
          expandArg = `fields($select=${fieldNames.join(",")})`;
        }
      }

      let query = this.graphClient
        .api(`/sites/${this.siteId}/lists/${listId}/items`)
        .expand(expandArg);

      if (filter && filter.trim().length > 0) {
        query = query.filter(filter);
      }
      if (orderBy && orderBy.trim().length > 0) {
        query = query.orderby(orderBy);
      }
      if (top && Number.isFinite(top)) {
        query = query.top(top as number);
      }

      const response = await query.get();
      return (response.value as SharePointListItem[]) || [];
    } catch (error) {
      console.error(`Error getting list items from ${listNameOrId}:`, error);
      throw error;
    }
  }

  async createListItem(
    listNameOrId: string,
    fields: Record<string, unknown>
  ): Promise<SharePointListItem> {
    try {
      if (!this.siteId) {
        await this.initializeSite();
      }

      const listId = await this.resolveListId(listNameOrId);

      const response = await this.graphClient
        .api(`/sites/${this.siteId}/lists/${listId}/items`)
        .post({ fields });

      return response as SharePointListItem;
    } catch (error) {
      console.error(`Error creating item in ${listNameOrId}:`, error);
      throw error;
    }
  }

  async updateListItem(
    listNameOrId: string,
    itemId: string,
    fields: Record<string, unknown>
  ): Promise<SharePointListItem> {
    try {
      if (!this.siteId) {
        await this.initializeSite();
      }

      const listId = await this.resolveListId(listNameOrId);

      const response = await this.graphClient
        .api(`/sites/${this.siteId}/lists/${listId}/items/${itemId}/fields`)
        .patch(fields);

      return response as SharePointListItem;
    } catch (error) {
      console.error(`Error updating item in ${listNameOrId}:`, error);
      throw error;
    }
  }

  async deleteListItem(listNameOrId: string, itemId: string): Promise<void> {
    try {
      if (!this.siteId) {
        await this.initializeSite();
      }

      const listId = await this.resolveListId(listNameOrId);

      await this.graphClient
        .api(`/sites/${this.siteId}/lists/${listId}/items/${itemId}`)
        .delete();
    } catch (error) {
      console.error(`Error deleting item from ${listNameOrId}:`, error);
      throw error;
    }
  }

  async uploadFile(
    libraryName: string,
    fileName: string,
    fileContent: Blob
  ): Promise<DriveItem> {
    try {
      if (!this.siteId) {
        await this.initializeSite();
      }

      const response = await this.graphClient
        .api(
          `/sites/${this.siteId}/drive/root:/${libraryName}/${fileName}:/content`
        )
        .put(fileContent);

      return response as DriveItem;
    } catch (error) {
      console.error(`Error uploading file to ${libraryName}:`, error);
      throw error;
    }
  }
}

// Types
interface SharePointListItem {
  id: string;
  fields: Record<string, unknown>;
  [key: string]: unknown;
}

interface DriveItem {
  id: string;
  name: string;
  webUrl: string;
  [key: string]: unknown;
}

// Export singleton instance
export const sharePointClient = new SharePointClient();

// Export function to check connection
export async function checkSharePointConnection(): Promise<{
  success: boolean;
  message: string;
}> {
  try {
    await sharePointClient.initializeSite();
    return { success: true, message: "Conexión exitosa con SharePoint" };
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : "Error desconocido";
    return {
      success: false,
      message: `Error de conexión: ${errorMessage}`,
    };
  }
}