/**
 * SharePoint List Name to ID Mappings
 * Centralizes all SharePoint list identifiers for the SAM ERP application
 */

export const SHAREPOINT_LISTS = {
  // Trabajadores - Employee management
  TRABAJADORES: {
    name: 'TBL_TRABAJADORES',
    id: import.meta.env.VITE_SP_LIST_TRABAJADORES_ID || '8fe1853f-9f5d-42af-b966-8d3cd32d4042',
    displayName: 'Trabajadores'
  },
  
  // Mandantes - Client/Principal management
  MANDANTES: {
    name: 'tbl_mandantes',
    id: import.meta.env.VITE_SP_LIST_MANDANTES_ID || '8dd78484-125c-42ea-9830-dd9854a028f6',
    displayName: 'Mandantes'
  },
  
  // Servicios - Services catalog
  SERVICIOS: {
    name: 'TBL_SERVICIOS',
    id: import.meta.env.VITE_SP_LIST_SERVICIOS_ID || '546a4ed3-e482-48b7-97d8-075674c47e91',
    displayName: 'Servicios'
  },
  
  // Vacaciones - Vacation/Leave management
  VACACIONES: {
    name: 'TBL_VACACIONES',
    id: import.meta.env.VITE_SP_LIST_VACACIONES_ID || '3264b76b-85e2-4c7c-bf11-2e7249108c65',
    displayName: 'Vacaciones'
  },
  
  // Contratos - Contracts management
  CONTRATOS: {
    name: 'TBL_CONTRATOS',
    id: import.meta.env.VITE_SP_LIST_CONTRATOS_ID || '63c7383e-89a5-4164-a2d3-7cc84616f60b',
    displayName: 'Contratos'
  },
  
  // Cursos - Training/Courses (OS10)
  CURSOS: {
    name: 'TBL_REGISTRO_CURSO_OS10',
    id: import.meta.env.VITE_SP_LIST_CURSOS_ID || '1a512283-a993-468a-ab51-c20ed0ee03b2',
    displayName: 'Cursos OS10'
  },

  // Additional lists
  USUARIOS: {
    name: 'Usuarios',
    id: import.meta.env.VITE_SP_LIST_USUARIOS_ID || '',
    displayName: 'Usuarios'
  },
  
  ROLES: {
    name: 'Roles',
    id: import.meta.env.VITE_SP_LIST_ROLES_ID || '',
    displayName: 'Roles'
  },
  
  DIRECTIVAS: {
    name: 'Directivas',
    id: import.meta.env.VITE_SP_LIST_DIRECTIVAS_ID || '',
    displayName: 'Directivas'
  },
  
  JORNADAS: {
    name: 'Jornadas',
    id: import.meta.env.VITE_SP_LIST_JORNADAS_ID || '',
    displayName: 'Jornadas'
  },
  
  CLIENTES: {
    name: 'Clientes',
    id: import.meta.env.VITE_SP_LIST_CLIENTES_ID || '',
    displayName: 'Clientes'
  }
} as const;

type Mapping = Record<string, string>;

/**
 * FIELD_MAPPINGS: Map SharePoint internal field names → app field names per list.
 */
export const FIELD_MAPPINGS = {
  TRABAJADORES: {
    ID: 'id',
    Title: 'title',
    Nombres: 'nombres',
    Apellidos: 'apellidos',
    RUT: 'rut',
    Nacimiento: 'nacimiento',
    Estado_Civil: 'estado_civil',
    Celular: 'celular',
    Correo_Empresa: 'correo_empresa',
    Telefono: 'telefono',
    Direccion: 'direccion',
    Ciudad_Pais: 'ciudad_pais',
    Ciudad_Estado: 'ciudad_estado',
    Ciudad_Nombre: 'ciudad_nombre',
    Ciudad_Calle: 'ciudad_calle',
    Ciudad_CPostal: 'ciudad_cpostal',
    Ciudad_Coordenadas: 'ciudad_coordenadas',
    Cargo: 'cargo',
    Tipo_Contrato: 'tipo_contrato',
    Sueldo_Base: 'sueldo_base',
    AFP: 'afp',
    Salud: 'salud',
    Banco: 'banco',
    Tipo_Cuenta: 'tipo_cuenta',
    Numero_Cuenta: 'numero_cuenta',
    Fecha_Ingreso: 'fecha_ingreso',
    FOTO_TRABAJADOR_: 'foto_trabajador',
    DOC_CURSO: 'doc_curso',
    ESTADO_: 'estado',
    Notas: 'notas',
  },
  MANDANTES: {
    ID: 'id',
    Nombre_mandante: 'nombre',
    Rut_mandante: 'rut',
    Direccion_mandante: 'direccion',
    Razon_Social_mandante: 'razon_social',
    Giro_mandante: 'giro',
    telefono_mandante: 'telefono',
    Representante_legal: 'representante_legal',
    _OldID: 'old_id',
    Adjuntos: 'adjuntos',
    ContentTypeId: 'content_type_id',
    Modified: 'modified',
    Created: 'created',
    Author: 'author',
    Editor: 'editor',
  },
  SERVICIOS: {
    ID: 'id',
    NOMBRE: 'nombre',
    RUT_CLIENTE: 'rut_cliente',
    TIPO_EMPRESA: 'tipo_empresa',
    EMPRESA: 'empresa',
    DIRECCION: 'direccion',
    UBICACION: 'ubicacion',
    ZONA: 'zona',
    DOTACION: 'dotacion',
    TELEFONO: 'telefono',
    RESPONSABLE: 'responsable',
    FECHA_INICIO: 'fecha_inicio',
    FECHA_TERMINO: 'fecha_termino',
    ESTADO: 'estado',
  },
  CONTRATOS: {
    Id: 'id',
    Title: 'nombre',
    MandanteId: 'mandante_id',
    FechaInicio: 'fecha_inicio',
    FechaFin: 'fecha_fin',
    Estado: 'estado',
    Valor: 'valor',
  },
  USUARIOS: {
    Id: 'id',
    Title: 'nombre',
    Email: 'email',
    Estado: 'estado',
    Rol: 'rol',
    FechaCreacion: 'fecha_creacion',
  },
  CLIENTES: {
    Id: 'id',
    Title: 'razon_social',
    RUT: 'rut',
    NombreContacto: 'nombre_contacto',
    Email: 'email',
    Telefono: 'telefono',
    Direccion: 'direccion',
    Estado: 'estado',
  },
  VACACIONES: {
    Id: 'id',
    TrabajadorId: 'trabajador_id',
    TrabajadorNombre: 'trabajador_nombre',
    FechaInicio: 'fecha_inicio',
    FechaFin: 'fecha_fin',
    DiasSolicitados: 'dias_solicitados',
    Estado: 'estado',
    Observaciones: 'observaciones',
  },
  DIRECTIVAS: {
    Id: 'id',
    Title: 'titulo',
    Descripcion: 'descripcion',
    Numero: 'numero',
    FechaEmision: 'fecha_emision',
    Vigente: 'vigente',
    Categoria: 'categoria',
    ArchivoUrl: 'archivo_url',
  },
} as const;

// Export FIELD_MAPPINGS for external use
export type FieldMappings = typeof FIELD_MAPPINGS;
export type FieldMappingKey = keyof FieldMappings;

type SPItemBase = {
  id?: string | number;
  fields?: Record<string, unknown>;
} & Record<string, unknown>;

/**
 * Transform SharePoint items to app format using FIELD_MAPPINGS.
 */
export function transformSharePointData<K extends FieldMappingKey, T = Record<string, unknown>>(
  listName: K,
  items: SPItemBase[]
): T[] {
  const mapping: Mapping = FIELD_MAPPINGS[listName] as Mapping;
  if (!mapping || !items) return [];

  return items.map((item) => {
    const transformed: Record<string, unknown> = {};
    const fields = (item?.fields ?? item) as Record<string, unknown>;

    transformed.id = (item?.id ??
      (fields?.Id as string | number | undefined) ??
      (fields?.ID as string | number | undefined)) as string | number | undefined;

    Object.entries(mapping).forEach(([spField, appField]) => {
      if (fields && Object.prototype.hasOwnProperty.call(fields, spField)) {
        transformed[appField] = fields[spField];
      }
    });

    return transformed as T;
  });
}

/**
 * Helper function to get list ID by name
 */
export function getListId(listKey: keyof typeof SHAREPOINT_LISTS): string {
  return SHAREPOINT_LISTS[listKey].id;
}

/**
 * Helper function to get list display name
 */
export function getListDisplayName(listKey: keyof typeof SHAREPOINT_LISTS): string {
  return SHAREPOINT_LISTS[listKey].displayName;
}

/**
 * Helper function to get list internal name
 */
export function getListName(listKey: keyof typeof SHAREPOINT_LISTS): string {
  return SHAREPOINT_LISTS[listKey].name;
}

/**
 * Validate that all required list IDs are configured
 */
export function validateListConfiguration(): { valid: boolean; missing: string[] } {
  const missing: string[] = [];
  
  Object.entries(SHAREPOINT_LISTS).forEach(([key, config]) => {
    if (!config.id || config.id.length !== 36) {
      missing.push(key);
    }
  });
  
  return {
    valid: missing.length === 0,
    missing
  };
}