INSTRUCCIONES

1) Copia la carpeta src/auth dentro de tu proyecto.
2) Asegúrate que SharePointAuthContext.tsx importe:
   import { msalInstance } from "@/auth/msalInstance";
3) Corrige el NaN en Servicios.tsx:

const dotTrim = form.dotacion.trim();
const dotacionNum = dotTrim === "" ? null : Number(dotTrim);

if (dotTrim !== "" && !Number.isFinite(dotacionNum)) {
  alert("DOTACION debe ser numérica");
  return;
}

4) Commit y deploy.