import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  type ReactNode,
} from "react";
import type { AccountInfo } from "@azure/msal-browser";
import { msalInstance } from "@/auth/msalInstance";
import { loginRequest } from "@/auth/msalConfig";
import { getAccessToken as coreGetAccessToken } from "@/auth/authService";

interface SharePointUser {
  id: string;
  displayName: string;
  mail: string;
  userPrincipalName: string;
  jobTitle?: string;
  department?: string;
  permisos: Record<string, string[]>;
}

interface SharePointAuthContextType {
  user: SharePointUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  /** True once MSAL finished processing redirect + cache */
  ready: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  /** Returns access token or triggers interactive login (redirect) */
  getAccessToken: () => Promise<string>;
  hasPermission: (module: string, level: string) => boolean;
  canRead: (module: string) => boolean;
  canWrite: (module: string) => boolean;
  canAdmin: (module: string) => boolean;
}

const SharePointAuthContext = createContext<SharePointAuthContextType | undefined>(
  undefined
);

export function SharePointAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SharePointUser | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    void initializeAuth();
  }, []);

  const initializeAuth = async () => {
    try {
      await msalInstance.initialize();

      // Important for SPA redirect flows: process the redirect response first
      const redirectResult = await msalInstance.handleRedirectPromise();
      if (redirectResult?.account) {
        msalInstance.setActiveAccount(redirectResult.account);
      }

      // Ensure an active account exists (e.g., after refresh)
      const active = msalInstance.getActiveAccount();
      const accounts = msalInstance.getAllAccounts();
      const account = (active ?? (accounts.length ? (accounts[0] as AccountInfo) : null)) as
        | AccountInfo
        | null;

      if (account) {
        msalInstance.setActiveAccount(account);
        setIsAuthenticated(true);
        await loadUserProfile(account);
      } else {
        setUser(null);
        setIsAuthenticated(false);
      }
    } catch (error) {
      console.error("Error initializing MSAL:", error);
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
      setReady(true);
    }
  };

  const loadUserProfile = async (account: AccountInfo) => {
    try {
      const token = await coreGetAccessToken();

      const response = await fetch("https://graph.microsoft.com/v1.0/me", {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Error al obtener el perfil: ${response.status}`);
      }

      const profile = await response.json();

      const jobTitle = (profile.jobTitle as string | undefined) || "";
      const isAdmin =
        jobTitle.toLowerCase().includes("admin") ||
        jobTitle.toLowerCase().includes("jefe");

      const defaultPermisos: Record<string, string[]> = {
        rrhh: ["lectura"],
        administradores: ["lectura"],
        osp: ["lectura"],
        usuarios: isAdmin
          ? ["lectura", "escritura", "administracion"]
          : ["lectura"],
      };

      const userData: SharePointUser = {
        id: profile.id,
        displayName: profile.displayName,
        mail: profile.mail,
        userPrincipalName: profile.userPrincipalName,
        jobTitle: profile.jobTitle,
        department: profile.department,
        permisos: defaultPermisos,
      };

      setUser(userData);
      setIsAuthenticated(true);
    } catch (error) {
      console.error("Error loading user profile:", error);
      setUser(null);
      setIsAuthenticated(false);
    }
  };

  const login = async () => {
    // Prefer redirect flow to avoid COOP/window.close warnings and popup blockers
    await msalInstance.loginRedirect(loginRequest);
  };

  const logout = async () => {
    // Redirect logout is the most reliable across browsers
    await msalInstance.logoutRedirect({
      postLogoutRedirectUri: window.location.origin,
    });
    // State will reset on reload
  };

  const getAccessToken = async () => {
    try {
      return await coreGetAccessToken();
    } catch (e) {
      // If there is no session, trigger interactive login via redirect
      const msg = e instanceof Error ? e.message : String(e);
      if (msg.toLowerCase().includes("no authenticated user") || msg.toLowerCase().includes("no hay sesión")) {
        await login();
      }
      throw e;
    }
  };

  const hasPermission = (module: string, level: string) => {
    if (!user) return false;
    const permisosModulo = user.permisos[module] || [];
    return permisosModulo.includes(level);
  };

  const canRead = (module: string) => hasPermission(module, "lectura");
  const canWrite = (module: string) => hasPermission(module, "escritura");
  const canAdmin = (module: string) => hasPermission(module, "administracion");

  return (
    <SharePointAuthContext.Provider
      value={{
        user,
        isAuthenticated,
        isLoading,
        ready,
        login,
        logout,
        getAccessToken,
        hasPermission,
        canRead,
        canWrite,
        canAdmin,
      }}
    >
      {children}
    </SharePointAuthContext.Provider>
  );
}

export function useSharePointAuth(): SharePointAuthContextType {
  const context = useContext(SharePointAuthContext);
  if (!context) {
    throw new Error(
      "useSharePointAuth must be used within a SharePointAuthProvider"
    );
  }
  return context;
}
