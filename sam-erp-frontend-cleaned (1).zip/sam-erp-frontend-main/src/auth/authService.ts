import type { AccountInfo, SilentRequest } from "@azure/msal-browser";
import { msalInstance } from "./msalInstance";
import { loginRequest } from "./msalConfig";

function pickAccount(): AccountInfo | null {
  // Prefer active account, otherwise fall back to the first cached account
  const active = msalInstance.getActiveAccount();
  if (active) return active;

  const accounts = msalInstance.getAllAccounts();
  if (accounts.length) {
    msalInstance.setActiveAccount(accounts[0]);
    return accounts[0];
  }
  return null;
}

// ✅ ESTO es lo que Netlify dice que falta:
export async function getAccessToken(scopes: string[] = loginRequest.scopes): Promise<string> {
  const account = pickAccount();
  if (!account) throw new Error("No authenticated user found");

  const req: SilentRequest = { account, scopes };
  const res = await msalInstance.acquireTokenSilent(req);
  return res.accessToken;
}
