
# SAM ERP – Patch autenticación SharePoint (MSAL)

Este ZIP corrige el error:
❌ No authenticated user found

Incluye:
- SharePointAuthContext con MSAL bien inicializado
- Manejo correcto de redirect + activeAccount
- getAccessToken seguro (loginRedirect si no hay sesión)

## Cómo usar
1. Copia `src/contexts/SharePointAuthContext.tsx`
2. Envuelve tu App con `SharePointAuthProvider`
3. Usa `useSharePointAuth()` antes de llamar a SharePoint

## Variables requeridas (.env)
VITE_AZURE_CLIENT_ID=xxxxx
VITE_AZURE_TENANT_ID=xxxxx
VITE_REDIRECT_URI=https://samerp.cl/
