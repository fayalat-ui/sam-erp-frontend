
import { useSharePointAuth } from "@/contexts/SharePointAuthContext";

const BASE = "https://seguryservicios.sharepoint.com";

export async function getTrabajadores(listGuid: string) {
  const { getAccessToken } = useSharePointAuth();
  const token = await getAccessToken();
  if (!token) return [];

  const res = await fetch(
    `${BASE}/_api/web/lists(guid'${listGuid}')/items?$top=200`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json;odata=nometadata",
      },
    }
  );

  if (!res.ok) throw new Error("Error cargando trabajadores");
  const json = await res.json();
  return json.value;
}
