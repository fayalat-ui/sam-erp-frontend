
import { createContext, useContext, useEffect, useState } from "react";
import { PublicClientApplication } from "@azure/msal-browser";

const msalConfig = {
  auth: {
    clientId: import.meta.env.VITE_AZURE_CLIENT_ID,
    authority: `https://login.microsoftonline.com/${import.meta.env.VITE_AZURE_TENANT_ID}`,
    redirectUri: import.meta.env.VITE_REDIRECT_URI,
  },
};

const scopes = ["Sites.Read.All", "User.Read"];

export const msalInstance = new PublicClientApplication(msalConfig);

interface AuthContextType {
  isAuthenticated: boolean;
  getAccessToken: () => Promise<string | null>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const SharePointAuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    msalInstance.handleRedirectPromise().then((result) => {
      if (result?.account) {
        msalInstance.setActiveAccount(result.account);
        setIsAuthenticated(true);
      } else {
        const accounts = msalInstance.getAllAccounts();
        if (accounts.length > 0) {
          msalInstance.setActiveAccount(accounts[0]);
          setIsAuthenticated(true);
        }
      }
    });
  }, []);

  const getAccessToken = async () => {
    let account = msalInstance.getActiveAccount();

    if (!account) {
      const accounts = msalInstance.getAllAccounts();
      if (accounts.length > 0) {
        account = accounts[0];
        msalInstance.setActiveAccount(account);
      }
    }

    if (!account) {
      await msalInstance.loginRedirect({ scopes });
      return null;
    }

    const result = await msalInstance.acquireTokenSilent({
      account,
      scopes,
    });

    return result.accessToken;
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, getAccessToken }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useSharePointAuth = () => useContext(AuthContext);
