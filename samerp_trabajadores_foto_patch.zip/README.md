# SAM ERP – Patch mapeo TBL_TRABAJADORES (incluye FOTO_TRABAJADOR_)

Este ZIP contiene archivos listos para copiar/pegar en tu proyecto React/TS para:
- Mapear campos de SharePoint (TBL_TRABAJADORES) a un modelo limpio tipo "SAM"
- Construir la URL de la foto desde el campo Thumbnail `FOTO_TRABAJADOR_`
- (Opcional) obtener la imagen como `blob:` usando tu access token para evitar 401/403 en <img>

## Archivos
- `src/lib/sharepoint/trabajadoresMapper.ts`
- `src/lib/sharepoint/fotoTrabajador.ts`

## Cómo integrar (rápido)
1) Copia la carpeta `src/` de este ZIP dentro de tu repo (fusiona con tu estructura).
2) En tu servicio donde traes items de SharePoint, importa y aplica:
   ```ts
   import { mapTrabajadorFromSharePoint } from "@/lib/sharepoint/trabajadoresMapper";
   const trabajadoresSAM = items.map(mapTrabajadorFromSharePoint);
   ```
3) En tu UI:
   ```tsx
   <img src={t.foto_trabajador_url ?? "/avatar-default.png"} ... />
   ```

## Parámetros
- LIST GUID (TBL_TRABAJADORES): `8fe1853f-9f5d-42af-b966-8d3cd32d4042`
- SharePoint base: `https://seguryservicios.sharepoint.com`

Si tu tenant usa otra base de sitio (por ejemplo `/sites/Seguryservicios`), ajusta `SP_BASE` en `fotoTrabajador.ts`.
