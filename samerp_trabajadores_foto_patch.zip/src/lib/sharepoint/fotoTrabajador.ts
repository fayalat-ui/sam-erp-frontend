/**
 * SharePoint Thumbnail -> URL de Attachment ($value)
 * Campo: FOTO_TRABAJADOR_ (Thumbnail) expuesto como string JSON:
 *   {"fileName":"Reserved_ImageAttachment_...png","originalImageName":"..."}
 *
 * Requiere estar autenticado contra SharePoint para que la URL funcione.
 */

export const LIST_GUID_TRABAJADORES = "8fe1853f-9f5d-42af-b966-8d3cd32d4042";

// Ajusta si tu SharePoint requiere /sites/<site> en la base.
// Ej: "https://seguryservicios.sharepoint.com/sites/seguryservicios"
export const SP_BASE = "https://seguryservicios.sharepoint.com";

export type FotoTrabajadorRaw = string | { fileName?: string } | null | undefined;

function safeJsonParse(s: string): any | null {
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}

/**
 * Construye URL al binario del attachment:
 *  .../AttachmentFiles('<fileName>')/$value
 */
export function buildFotoTrabajadorUrl(item: { Id?: number; FOTO_TRABAJADOR_?: FotoTrabajadorRaw }) {
  const id = item?.Id;
  if (!id) return null;

  const raw = item?.FOTO_TRABAJADOR_;
  if (!raw) return null;

  const meta = typeof raw === "string" ? safeJsonParse(raw) : raw;
  const fileName = meta?.fileName;

  if (!fileName || typeof fileName !== "string") return null;

  // Encode para seguridad: espacios, símbolos y comillas simples
  const encoded = encodeURIComponent(fileName).replace(/'/g, "%27");

  return `${SP_BASE}/_api/web/lists(guid'${LIST_GUID_TRABAJADORES}')/items(${id})/AttachmentFiles('${encoded}')/$value`;
}

/**
 * Si <img src="..."> te da 401/403, puedes bajar la imagen con token y mostrarla como blob URL.
 * OJO: Recuerda hacer URL.revokeObjectURL cuando ya no la uses.
 */
export async function fetchImageBlobUrl(url: string, accessToken: string): Promise<string | null> {
  const r = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!r.ok) return null;
  const blob = await r.blob();
  return URL.createObjectURL(blob);
}
