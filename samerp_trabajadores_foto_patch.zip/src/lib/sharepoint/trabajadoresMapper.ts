import { buildFotoTrabajadorUrl } from "./fotoTrabajador";

/**
 * Mapper SharePoint -> SAM (subset de campos que estás usando)
 * Mantiene nombres limpios y consistentes.
 */
export function mapTrabajadorFromSharePoint(sp: any) {
  return {
    // Identificación
    tipo_documento: sp.T_documento ?? null,
    numero_documento: sp.N_documento ?? null,
    nombres: sp.Nombres ?? null,
    apellidos: sp.Apellidos ?? null,
    fecha_nacimiento: sp.NACIMIENTO ?? null,

    // Contacto / Dirección
    direccion: sp.DIRECCION_ANTIGUA ?? null,
    ciudad: sp.Ciudad ?? null,
    email_personal: sp.Email_PERSONAL ?? null,
    celular: sp.Celular ?? null,

    // Datos personales
    nacionalidad: sp.Nacionalidad ?? null,
    genero: sp.GENERO ?? null,
    estado_civil: sp.Estado_civil ?? null,
    nivel_educativo: sp.Nivel_educativo ?? null,
    profesion: sp.Profesion ?? null,
    inscripcion_militar: sp.Inscripcion_militar ?? null,

    // Emergencia
    contacto_emergencia: sp.Contacto_Emergencia ?? null,
    telefono_emergencia: sp.Telefono_Emergencia ?? null,

    // Laboral
    estado: sp.Estado ?? null,

    // Notas
    notas: sp.Notas ?? null,

    // Pago
    banco_pago: sp.BANCO_PAGO ?? null,
    tipo_cuenta_pago: sp.TIPO_CUENTA_PAGO ?? null,
    numero_cuenta_pago: sp.NUMERO_CUENTA_PAGO ?? null,
    titular_cuenta_pago: sp.TITULAR_CUENTA_PAGO ?? null,

    // Foto (SharePoint)
    foto_trabajador_url: buildFotoTrabajadorUrl(sp),
    foto_trabajador_meta: sp.FOTO_TRABAJADOR_ ?? null,

    // Auditoría (si la usas)
    sp_creado: sp.Creado ?? null,
    sp_modificado: sp.Modificado ?? null,
    sp_creado_por: sp["Creado por"] ?? null,
  };
}
