import React, { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import type { AccountInfo } from "@azure/msal-browser";
import { msalInstance } from "@/auth/msalInstance";
import { loginRequest } from "@/auth/msalConfig";
import { getAccessToken as coreGetAccessToken } from "@/auth/authService";

const SharePointAuthContext = createContext<any>(undefined);

export function SharePointAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<any>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => { void initializeAuth(); }, []);

  const initializeAuth = async () => {
    try {
      await msalInstance.initialize();
      const redirectResult = await msalInstance.handleRedirectPromise();
      if (redirectResult?.account) msalInstance.setActiveAccount(redirectResult.account);

      const active = msalInstance.getActiveAccount() ?? msalInstance.getAllAccounts()[0];
      if (active) {
        msalInstance.setActiveAccount(active);
        setIsAuthenticated(true);
        await loadUserProfile(active as AccountInfo);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const loadUserProfile = async (_: AccountInfo) => {
    const token = await coreGetAccessToken();
    const res = await fetch("https://graph.microsoft.com/v1.0/me", {
      headers: { Authorization: `Bearer ${token}` },
    });
    const profile = await res.json();
    setUser(profile);
  };

  const login = async () => {
    const r = await msalInstance.loginPopup(loginRequest);
    if (r.account) {
      msalInstance.setActiveAccount(r.account);
      setIsAuthenticated(true);
      await loadUserProfile(r.account as AccountInfo);
    }
  };

  const logout = async () => {
    await msalInstance.logoutPopup({ postLogoutRedirectUri: window.location.origin });
    setUser(null);
    setIsAuthenticated(false);
  };

  return (
    <SharePointAuthContext.Provider value={{ user, isAuthenticated, isLoading, login, logout, getAccessToken: coreGetAccessToken }}>
      {children}
    </SharePointAuthContext.Provider>
  );
}

export const useSharePointAuth = () => useContext(SharePointAuthContext);