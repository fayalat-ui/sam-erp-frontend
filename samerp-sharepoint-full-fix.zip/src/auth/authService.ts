import type { AccountInfo, SilentRequest } from "@azure/msal-browser";
import { msalInstance } from "./msalInstance";
import { loginRequest } from "./msalConfig";

function pickAccount(): AccountInfo | null {
  return msalInstance.getActiveAccount() ?? msalInstance.getAllAccounts()[0] ?? null;
}

export async function getAccessToken(scopes: string[] = loginRequest.scopes): Promise<string> {
  const account = pickAccount();
  if (!account) throw new Error("No authenticated user found");

  msalInstance.setActiveAccount(account);

  const req: SilentRequest = { account, scopes };
  const res = await msalInstance.acquireTokenSilent(req);
  return res.accessToken;
}