import { useState, useEffect } from "react";
import { useSharePointAuth } from "@/contexts/SharePointAuthContext";

export function useSharePointData<T>(service: any, options: any) {
  const [data, setData] = useState<T[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const { isAuthenticated, getAccessToken } = useSharePointAuth();

  const fetchData = async () => {
    if (options?.enabled === false || !isAuthenticated) return;
    setLoading(true);
    try {
      const token = await getAccessToken();
      const result = await service.getAll(token, {
        select: options.select,
        filter: options.filter,
      });
      setData(result);
    } catch (e: any) {
      setError(e);
      setData([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [isAuthenticated, options?.listName]);

  return { data, loading, error, refetch: fetchData };
}