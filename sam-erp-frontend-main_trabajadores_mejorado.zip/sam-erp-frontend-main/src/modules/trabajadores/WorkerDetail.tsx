import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getTrabajadorById } from "@/services/sharepoint/trabajadores";
import { WorkerEditDialog } from "@/modules/trabajadores/WorkerEditDialog";

type FieldSpec = { label: string; value: any };

function formatDate(value: any) {
  if (!value) return "—";
  try {
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return String(value);
    return d.toLocaleDateString("es-CL");
  } catch {
    return String(value);
  }
}

function getPhotoUrl(worker: any) {
  const raw = worker?.FOTO_TRABAJADOR_;
  if (!raw) return "";
  if (typeof raw === "string") return raw;
  // SharePoint a veces devuelve objetos con distintas claves
  return raw?.Url || raw?.url || raw?.href || raw?.ServerRelativeUrl || "";
}

function initials(name: string) {
  const parts = (name || "").trim().split(/\s+/).filter(Boolean);
  const a = parts[0]?.[0] ?? "";
  const b = parts[1]?.[0] ?? parts[0]?.[1] ?? "";
  return (a + b).toUpperCase() || "??";
}

function Section({ title, fields, fullWidth }: { title: string; fields: FieldSpec[]; fullWidth?: boolean }) {
  return (
    <Card className={fullWidth ? "md:col-span-2" : ""}>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm tracking-wide text-muted-foreground">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {fields.map((f) => (
          <div key={f.label} className="flex items-start justify-between gap-4">
            <div className="text-sm text-muted-foreground">{f.label}</div>
            <div className="text-sm font-medium text-right break-words max-w-[60%]">{f.value ?? "—"}</div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

export default function WorkerDetail() {
  const { id } = useParams();
  const [worker, setWorker] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [openEdit, setOpenEdit] = useState(false);

  const refetch = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const data = await getTrabajadorById(id);
      setWorker(data);
    } catch (e) {
      console.error(e);
      setWorker(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (loading && !worker) return <p className="p-4">Cargando…</p>;
  if (!worker) return <p className="p-4">No se encontró el trabajador.</p>;

  const nombre =
    `${worker.Nombres ?? ""} ${worker.Apellidos ?? ""}`.trim() ||
    worker.NOMNRE_COMPLETO ||
    worker.NOMBRE_COMPLETO ||
    worker.Title ||
    "Trabajador";

  const rut = worker.N_documento || worker.RUT || worker.rut || "—";
  const photoUrl = getPhotoUrl(worker);

  return (
    <>
      <div className="flex items-start justify-between gap-3 mb-4">
        <div className="flex items-start gap-4">
          <Avatar className="h-16 w-16">
            {photoUrl ? <AvatarImage src={photoUrl} alt={nombre} /> : null}
            <AvatarFallback className="text-lg">{initials(nombre)}</AvatarFallback>
          </Avatar>

          <div>
            <h2 className="text-2xl font-semibold leading-tight">{nombre}</h2>
            <p className="text-sm text-muted-foreground">RUT: {rut}</p>

            <div className="mt-2 flex flex-wrap gap-2">
              <Badge variant="secondary">Estado: {worker.Estado ?? "—"}</Badge>
              <Badge variant="secondary">Rol: {worker.ROL ?? "—"}</Badge>
              <Badge variant="secondary">Celular: {worker.Celular ?? "—"}</Badge>
              <Badge variant="secondary">Ciudad: {worker.Ciudad ?? "—"}</Badge>
            </div>
          </div>
        </div>

        <Button onClick={() => setOpenEdit(true)}>Editar</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Section
          title="INFORMACIÓN PERSONAL BÁSICA"
          fields={[
            { label: "T_documento", value: worker.T_documento ?? "—" },
            { label: "N_documento", value: worker.N_documento ?? "—" },
            { label: "Nombres", value: worker.Nombres ?? "—" },
            { label: "Apellidos", value: worker.Apellidos ?? "—" },
            { label: "NACIMIENTO", value: formatDate(worker.NACIMIENTO) },
            { label: "GENERO", value: worker.GENERO ?? "—" },
            { label: "Nacionalidad", value: worker.Nacionalidad ?? "—" },
            { label: "Estado_civil", value: worker.Estado_civil ?? "—" },
          ]}
        />

        <Section
          title="INFORMACIÓN DE CONTACTO"
          fields={[
            { label: "Email_PERSONAL", value: worker.Email_PERSONAL ?? "—" },
            { label: "Celular", value: worker.Celular ?? "—" },
            { label: "Dirección", value: worker.DIRECCION_ANTIGUA ?? "—" },
            { label: "Ciudad", value: worker.Ciudad ?? "—" },
          ]}
        />

        <Section
          title="CONTACTO DE EMERGENCIA"
          fields={[
            { label: "Contacto_Emergencia", value: worker.Contacto_Emergencia ?? "—" },
            { label: "Telefono_Emergencia", value: worker.Telefono_Emergencia ?? "—" },
          ]}
        />

        <Section
          title="INFORMACIÓN ACADÉMICA Y PROFESIONAL"
          fields={[
            { label: "Nivel_educativo", value: worker.Nivel_educativo ?? "—" },
            { label: "Profesion", value: worker.Profesion ?? "—" },
            { label: "Inscripcion_militar", value: worker.Inscripcion_militar ?? "—" },
          ]}
        />

        <Section
          title="INFORMACIÓN LABORAL"
          fields={[
            { label: "ROL", value: worker.ROL ?? "—" },
            { label: "Estado", value: worker.Estado ?? "—" },
          ]}
        />

        <Section
          title="INFORMACIÓN BANCARIA"
          fields={[
            { label: "BANCO_PAGO", value: worker.BANCO_PAGO ?? "—" },
            { label: "TIPO_CUENTA_PAGO", value: worker.TIPO_CUENTA_PAGO ?? "—" },
            { label: "NUMERO_CUENTA_PAGO", value: worker.NUMERO_CUENTA_PAGO ?? "—" },
            { label: "TITULAR_CUENTA_PAGO", value: worker.TITULAR_CUENTA_PAGO ?? "—" },
          ]}
        />

        <Section
          title="NOTAS Y OBSERVACIONES"
          fullWidth
          fields={[{ label: "Notas", value: worker.Notas ?? "—" }]}
        />
      </div>

      <WorkerEditDialog
        open={openEdit}
        onOpenChange={setOpenEdit}
        worker={worker}
        trabajadorId={id || ""}
        onSaved={refetch}
      />
    </>
  );
}
