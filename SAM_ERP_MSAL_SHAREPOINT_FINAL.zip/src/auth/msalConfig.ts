import type { Configuration, PopupRequest } from "@azure/msal-browser";

const clientId =
  import.meta.env.VITE_AZURE_CLIENT_ID || "4523a41a-818e-4d92-8775-1ccf155e7327";

const tenantId =
  import.meta.env.VITE_AZURE_TENANT_ID || "2f7e4660-def9-427d-9c23-603e4e4dae55";

const redirectUri =
  import.meta.env.VITE_AZURE_REDIRECT_URI ||
  import.meta.env.VITE_REDIRECT_URI ||
  "https://samerp.cl/login";

const authority = `https://login.microsoftonline.com/${tenantId}`;

const rawScopes = import.meta.env.VITE_AZURE_SCOPES as string | undefined;
const scopes =
  rawScopes && rawScopes.trim().length > 0
    ? rawScopes
        .split(/[,\s]+/)
        .map((s) => s.trim())
        .filter(Boolean)
    : ["User.Read", "Sites.Read.All"];

export const msalConfig: Configuration = {
  auth: {
    clientId,
    authority,
    redirectUri,
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false,
  },
};

export const loginRequest: PopupRequest = {
  scopes,
};

export const graphConfig = {
  graphMeEndpoint: "https://graph.microsoft.com/v1.0/me",
  graphSitesEndpoint: "https://graph.microsoft.com/v1.0/sites",
};
