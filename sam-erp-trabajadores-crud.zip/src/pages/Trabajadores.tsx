// src/pages/Trabajadores.tsx
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { TrabajadorForm } from "@/components/TrabajadorForm";
import { trabajadoresService, type Trabajador, type TrabajadorInput } from "@/services/trabajadores";

export default function Trabajadores() {
  const [data, setData] = useState<Trabajador[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"create" | "edit">("create");
  const [selected, setSelected] = useState<Trabajador | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const rows = await trabajadoresService.getAll();
      setData(rows);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const onCreate = () => {
    setMode("create");
    setSelected(null);
    setOpen(true);
  };

  const onEdit = (row: Trabajador) => {
    setMode("edit");
    setSelected(row);
    setOpen(true);
  };

  const onSubmit = async (payload: TrabajadorInput | Partial<TrabajadorInput>) => {
    if (mode === "create") {
      await trabajadoresService.create(payload as TrabajadorInput);
    } else if (selected) {
      await trabajadoresService.update(selected.Id, payload as Partial<TrabajadorInput>);
    }
    await load();
  };

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Trabajadores</h1>
        <Button onClick={onCreate}>+ Nuevo</Button>
      </div>

      <div className="rounded-xl border overflow-hidden">
        <div className="grid grid-cols-12 gap-2 p-3 text-sm font-medium bg-muted/40">
          <div className="col-span-3">Nombre</div>
          <div className="col-span-3">Email</div>
          <div className="col-span-2">Celular</div>
          <div className="col-span-2">Estado</div>
          <div className="col-span-2 text-right">Acciones</div>
        </div>

        {loading ? (
          <div className="p-4 text-sm text-muted-foreground">Cargando...</div>
        ) : (
          data.map((r) => (
            <div key={r.Id} className="grid grid-cols-12 gap-2 p-3 text-sm border-t">
              <div className="col-span-3">{r.Nombres} {r.Apellidos}</div>
              <div className="col-span-3">{r.Email_PERSONAL ?? "-"}</div>
              <div className="col-span-2">{r.Celular ?? "-"}</div>
              <div className="col-span-2">{r.Estado ?? "-"}</div>
              <div className="col-span-2 flex justify-end">
                <Button size="sm" variant="outline" onClick={() => onEdit(r)}>✏️ Editar</Button>
              </div>
            </div>
          ))
        )}
      </div>

      <TrabajadorForm
        open={open}
        onOpenChange={setOpen}
        mode={mode}
        initial={selected}
        onSubmit={onSubmit}
      />
    </div>
  );
}
