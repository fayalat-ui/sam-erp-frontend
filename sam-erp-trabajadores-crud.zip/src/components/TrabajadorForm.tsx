// src/components/TrabajadorForm.tsx
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import type { Trabajador, TrabajadorInput } from "@/services/trabajadores";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  mode: "create" | "edit";
  initial?: Trabajador | null;
  onSubmit: (payload: TrabajadorInput | Partial<TrabajadorInput>) => Promise<void>;
};

export function TrabajadorForm({ open, onOpenChange, mode, initial, onSubmit }: Props) {
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState<TrabajadorInput>({
    Title: "",
    Nombres: "",
    Apellidos: "",
    Email_PERSONAL: "",
    Celular: "",
    Estado: "Activo",
    ROL: "",
  });

  useEffect(() => {
    if (mode === "edit" && initial) {
      setForm({
        Title: initial.Title ?? "",
        Nombres: initial.Nombres ?? "",
        Apellidos: initial.Apellidos ?? "",
        Email_PERSONAL: initial.Email_PERSONAL ?? "",
        Celular: initial.Celular ?? "",
        Estado: initial.Estado ?? "Activo",
        ROL: initial.ROL ?? "",
      });
    }
    if (mode === "create") {
      setForm({
        Title: "",
        Nombres: "",
        Apellidos: "",
        Email_PERSONAL: "",
        Celular: "",
        Estado: "Activo",
        ROL: "",
      });
    }
  }, [mode, initial]);

  const set = (k: keyof TrabajadorInput, v: string) =>
    setForm((p) => ({ ...p, [k]: v }));

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await onSubmit(form);
      onOpenChange(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>
            {mode === "create" ? "Nuevo trabajador" : "Editar trabajador"}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input placeholder="Título" value={form.Title ?? ""} onChange={(e) => set("Title", e.target.value)} />
          <Input placeholder="Rol" value={form.ROL ?? ""} onChange={(e) => set("ROL", e.target.value)} />
          <Input placeholder="Nombres" value={form.Nombres ?? ""} onChange={(e) => set("Nombres", e.target.value)} />
          <Input placeholder="Apellidos" value={form.Apellidos ?? ""} onChange={(e) => set("Apellidos", e.target.value)} />
          <Input placeholder="Email personal" value={form.Email_PERSONAL ?? ""} onChange={(e) => set("Email_PERSONAL", e.target.value)} />
          <Input placeholder="Celular" value={form.Celular ?? ""} onChange={(e) => set("Celular", e.target.value)} />
          <Input placeholder="Estado" value={form.Estado ?? ""} onChange={(e) => set("Estado", e.target.value)} />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? "Guardando..." : "Guardar"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
