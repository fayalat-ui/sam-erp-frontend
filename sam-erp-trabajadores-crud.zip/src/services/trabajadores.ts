// src/services/trabajadores.ts
import { sharePointService } from "@/lib/sharepoint";

export type Trabajador = {
  Id: number;
  Title?: string;
  Nombres?: string;
  Apellidos?: string;
  Email_PERSONAL?: string;
  Celular?: string;
  Estado?: string;
  ROL?: string;
};

export type TrabajadorInput = Omit<Trabajador, "Id">;

const LIST_NAME = "TBL_TRABAJADORES";

export const trabajadoresService = {
  async getAll() {
    return sharePointService.getAll<Trabajador>({
      listName: LIST_NAME,
      select: "Id,Title,Nombres,Apellidos,Email_PERSONAL,Celular,Estado,ROL",
      orderBy: "Id desc",
      top: 5000,
    });
  },

  async create(data: TrabajadorInput) {
    return sharePointService.create({
      listName: LIST_NAME,
      data,
    });
  },

  async update(id: number, data: Partial<TrabajadorInput>) {
    return sharePointService.update({
      listName: LIST_NAME,
      id,
      data,
    });
  },

  async remove(id: number) {
    return sharePointService.delete({
      listName: LIST_NAME,
      id,
    });
  },
};
