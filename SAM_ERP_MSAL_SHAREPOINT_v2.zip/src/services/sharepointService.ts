import { getAccessToken } from "../auth/authService";

const siteId =
  import.meta.env.VITE_SHAREPOINT_SITE_ID ||
  "seguryservicios.sharepoint.com,c5c17818-36f2-4c05-95e9-708bb3de1e77,90c85bba-a2ac-4d17-9f73-15db99245ac4";

async function graphFetch(url: string, init?: RequestInit) {
  const accessToken = await getAccessToken();

  const res = await fetch(url, {
    ...init,
    headers: {
      ...(init?.headers || {}),
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
  });

  if (!res.ok) {
    console.error("Error Graph:", res.status, await res.text());
    throw new Error(`Graph request failed: ${res.status}`);
  }

  return res.json();
}

export async function getListItems(listName: string) {
  if (!siteId) throw new Error("SITE_ID no configurado");

  const url = `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${listName}/items?expand=fields`;

  const data = await graphFetch(url);
  return (data.value ?? []).map((item: any) => item.fields);
}

export async function getTrabajadores() {
  return getListItems("TBL_TRABAJADORES");
}

export async function getMandantes() {
  // usa nombre lógico; idealmente configurado por ID vía ENV si quieres
  return getListItems("TBL_MANDANTES");
}

export async function getServicios() {
  return getListItems("TBL_SERVICIOS");
}
