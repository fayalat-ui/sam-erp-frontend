
import { msalInstance } from "./msal";

export async function getAccessToken(scopes: string[]) {
  let account = msalInstance.getActiveAccount();

  if (!account) {
    const accounts = msalInstance.getAllAccounts();
    if (accounts.length > 0) {
      account = accounts[0];
      msalInstance.setActiveAccount(account);
    }
  }

  if (!account) {
    await msalInstance.loginRedirect({ scopes });
    return null;
  }

  const result = await msalInstance.acquireTokenSilent({
    account,
    scopes,
  });

  return result.accessToken;
}
