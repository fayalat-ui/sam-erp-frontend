
# SAM ERP – Auth final corregido

Incluye:
- Bootstrap MSAL antes de renderizar React
- Fallback de cuentas desde cache
- localStorage como cache
- redirectUri único

Variables requeridas:
VITE_AZURE_CLIENT_ID
VITE_AZURE_TENANT_ID
VITE_REDIRECT_URI
VITE_AZURE_SCOPES
