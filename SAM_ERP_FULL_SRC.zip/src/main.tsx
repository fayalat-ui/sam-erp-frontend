import React from "react";
import ReactDOM from "react-dom/client";
import { MsalProvider } from "@azure/msal-react";
import { msalInstance } from "./auth/msalInstance";
import App from "./App";

async function bootstrap() {
  await msalInstance.initialize();

  const rootElement = document.getElementById("root");
  if (!rootElement) throw new Error("Root no encontrado");

  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <MsalProvider instance={msalInstance}>
        <App />
      </MsalProvider>
    </React.StrictMode>
  );
}

bootstrap();
