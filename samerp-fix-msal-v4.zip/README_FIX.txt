ARREGLO BUILD NETLIFY - MSAL (v4)

Tu error actual:
- SharePointAuthContext.tsx importa:
    import { loginRequest } from "@/auth/msalConfig";
    import { getAccessToken as coreGetAccessToken } from "@/auth/authService";
  y esos exports no existían con los archivos anteriores.

Este ZIP incluye:
- src/auth/msalConfig.ts      (exporta msalConfig y loginRequest)
- src/auth/msalInstance.ts
- src/auth/authService.ts     (exporta getAccessToken)

PASOS:
1) Borra cualquier archivo SIN extensión en src/auth:
   msalConfig, msalInstance, authService

2) Copia src/auth completo desde este ZIP a tu proyecto.

3) Commit + push + deploy.