import type { AccountInfo, SilentRequest } from "@azure/msal-browser";
import { msalInstance } from "./msalInstance";
import { loginRequest } from "./msalConfig";

function pickAccount(): AccountInfo | null {
  const accounts = msalInstance.getAllAccounts();
  return accounts.length ? accounts[0] : null;
}

/**
 * Function expected by SharePointAuthContext.tsx:
 *   import { getAccessToken as coreGetAccessToken } from "@/auth/authService";
 */
export async function getAccessToken(scopes: string[] = loginRequest.scopes): Promise<string> {
  const account = pickAccount();
  if (!account) throw new Error("No hay sesión activa (MSAL). Inicia sesión primero.");

  const req: SilentRequest = { account, scopes };
  const res = await msalInstance.acquireTokenSilent(req);
  return res.accessToken;
}

/**
 * Optional convenience exports (safe to keep)
 */
export const authService = {
  getAccount: pickAccount,
  async logout(): Promise<void> {
    const account = pickAccount() ?? undefined;
    await msalInstance.logoutPopup({ account });
  },
  async loginPopup(): Promise<void> {
    await msalInstance.loginPopup({ scopes: loginRequest.scopes });
  },
  async loginRedirect(): Promise<void> {
    await msalInstance.loginRedirect({ scopes: loginRequest.scopes });
  },
  acquireToken: getAccessToken,
};